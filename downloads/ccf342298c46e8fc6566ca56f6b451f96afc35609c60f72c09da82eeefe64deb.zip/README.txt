cfRNAdb public open-data download
mRNA & lncRNA · GSE133684

Matrix rows are native feature IDs. Columns are source analysis labels, not confirmed patients.
Unit: CPM_all_featureCounts_genes_denominator
NA is missing, not zero. The source feature selection and numeric precision are retained.
See provenance.json for channel and version definitions; source-qc.json retains available source QC.
Research interpretation and physical identity mapping require the source evidence.
