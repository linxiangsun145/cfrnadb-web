cfRNAdb public open-data download
Alternative promoters · GSE133684

Matrix rows are native feature IDs. Columns are source analysis labels, not confirmed patients.
Unit: salmon_estimated_fragments
NA is missing, not zero. The source feature selection and numeric precision are retained.
See provenance.json for channel and version definitions; source-qc.json retains available source QC.
Research interpretation and physical identity mapping require the source evidence.
